package com.example.paintingapp



import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import com.example.paintingapp.PaintView.Companion.colorList
import com.example.paintingapp.PaintView.Companion.currentBrush
import com.example.paintingapp.PaintView.Companion.pathList

class MainActivity : AppCompatActivity() {




    companion object{

        var path = Path()
        var paintBrush = Paint()

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()


        val redbutton = findViewById<ImageButton>(R.id.ColorRed)
        val yellowbutton = findViewById<ImageButton>(R.id.ColorYellow)
        val eraser = findViewById<ImageButton>(R.id.eraser)
        val bluebutton = findViewById<ImageButton>(R.id.ColorBlue)
        val blackbutton = findViewById<ImageButton>(R.id.ColorBlack)

        redbutton.setOnClickListener {
            Toast.makeText(this, "Picked Red Color", Toast.LENGTH_SHORT).show()
            paintBrush.color = Color.RED
            currentColor(paintBrush.color)
        }

        yellowbutton.setOnClickListener {
            Toast.makeText(this, "Picked Yellow Color", Toast.LENGTH_SHORT).show()
            paintBrush.color = Color.YELLOW
            currentColor(paintBrush.color)
        }

        eraser.setOnClickListener {
            Toast.makeText(this, "You Cleared The Painting", Toast.LENGTH_SHORT).show()
            pathList.clear()
            colorList.clear()
            path.reset()
        }

        bluebutton.setOnClickListener {
            Toast.makeText(this, "Picked Blue Color", Toast.LENGTH_SHORT).show()
            paintBrush.color = Color.BLUE
            currentColor(paintBrush.color)
        }

        blackbutton.setOnClickListener {
            Toast.makeText(this, "Picked Black Color", Toast.LENGTH_SHORT).show()
            paintBrush.color = Color.BLACK
            currentColor(paintBrush.color)
        }

    }
    private fun currentColor(color: Int){
        currentBrush = color
        path = Path()
    }
}